package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        findViewById<Button>(R.id.button).setOnClickListener { openList("Fruits") }
        findViewById<Button>(R.id.button2).setOnClickListener { openList("Animals") }
        findViewById<Button>(R.id.button3).setOnClickListener { openList("Vehicles") }
        findViewById<Button>(R.id.button4).setOnClickListener { openList("Countries") }
        findViewById<Button>(R.id.button5).setOnClickListener { openList("Colors") }
        findViewById<Button>(R.id.button6).setOnClickListener { openList("Sports") }
    }
    private fun openList(category: String) {
        val intent = Intent(this, MainActivity2::class.java)
        intent.putExtra("category", category)
        startActivity(intent)

    }
}
