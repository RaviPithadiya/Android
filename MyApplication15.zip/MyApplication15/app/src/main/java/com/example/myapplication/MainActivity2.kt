package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        val category = intent.getStringExtra("category")

        val items = when (category) {
            "Fruits" -> listOf("Apple", "Banana", "Mango", "Orange")
            "Animals" -> listOf("Dog", "Cat", "Elephant", "Lion")
            "Vehicles" -> listOf("Car", "Bike", "Bus", "Train")
            "Countries" -> listOf("India", "USA", "UK", "Canada")
            "Colors" -> listOf("Red", "Blue", "Green", "Yellow")
            "Sports" -> listOf("Cricket", "Football", "Tennis", "Hockey")

            else -> listOf("No items")
        }

        val listView: ListView = findViewById(R.id.listView)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedItem = items[position]
            val intent = Intent(this, MainActivity3::class.java)
            intent.putExtra("item", selectedItem)
            startActivity(intent)
        }

        }
}

