package com.example.myapplication

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main3)

        val item = intent.getStringExtra("item")

        val imageView = findViewById<ImageView>(R.id.imageView)
        val textView = findViewById<TextView>(R.id.infoTextView)
        val details = mapOf(
            "Apple" to (R.drawable.download to "Apple is a sweet fruit."),
            "Banana" to (R.drawable.banana to "Banana is yellow and soft."),
            "Dog" to (R.drawable.dog to "Dog is a loyal animal."),
        )
        val (imageRes, info) = details[item] ?: (0 to "No information available.")
        if (imageRes != 0) {
            imageView.setImageResource(imageRes)
        } else {
            imageView.setImageResource(android.R.color.transparent)
        }
        textView.text = info ?: ""

    }
}
