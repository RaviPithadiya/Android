package com.example.myapplication

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ListView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val firstname = findViewById<EditText>(R.id.edittextName)
        val lastname = findViewById<EditText>(R.id.edittextName1)
        val group = findViewById<RadioGroup>(R.id.radioGroupGender)
        val checkbox = findViewById<CheckBox>(R.id.checkReading)
        val checkbox1 = findViewById<CheckBox>(R.id.checkMusic)
        val checkbox2 = findViewById<CheckBox>(R.id.checkSports)
        val spinner = findViewById<Spinner>(R.id.spinnerCountry)
        val button = findViewById<Button>(R.id.button)
        val textView = findViewById<TextView>(R.id.textView)
        val listView = findViewById<ListView>(R.id.listView)

        val items = arrayOf("Rajkot", "Surat", "jamanagar")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)

        val cities = arrayOf("Ahmedabad", "Baroda", "Bhavnagar", "Junagadh", "Morbi")
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, cities)
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedItem = cities[position]
            Toast.makeText(this, "Clicked: $selectedItem", Toast.LENGTH_SHORT).show()
        }


        button.setOnClickListener {
            val name = firstname.text.toString() + " " + lastname.text.toString()
            val genderId = group.checkedRadioButtonId
            val gender =
                if (genderId != -1) findViewById<RadioButton>(genderId).text else "Not Selected"

            var hobbies = ""
            if (checkbox.isChecked) hobbies += "Reading "
            if (checkbox1.isChecked) hobbies += "Sports "
            if (checkbox2.isChecked) hobbies += "Writing "
            val country = spinner.selectedItem.toString()
            textView.text =
                "Name: $name\nGender: $gender\nHobbies: $hobbies\nCountry: $country\n"
        }
    }
}