package com.example.myloginreg

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
       val text = findViewById<EditText>(R.id.editTextText)
        val text1 = findViewById<EditText>(R.id.editTextText2)
        val btn = findViewById<Button>(R.id.button4)
        val btn1 = findViewById<Button>(R.id.button5)
        val textview = findViewById<TextView>(R.id.textView2)

        btn.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }

        var db = openOrCreateDatabase("UserDB", MODE_PRIVATE, null)
        db.execSQL("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, fname TEXT, username TEXT, password TEXT)")

        btn1.setOnClickListener {

            val usernameText = text.text.toString().trim()
            val passwordText = text1.text.toString().trim()

            if (usernameText.isEmpty() || passwordText.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cursor = db.rawQuery(
                "SELECT * FROM users WHERE username = ? AND password = ?",
                arrayOf(usernameText, passwordText)
            )

            if (cursor.moveToFirst()) {
                cursor.close()
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()

                // Move to next activity on successful login
                val intent = Intent(this, MainActivity3::class.java)  // Replace NextActivity with your target
                startActivity(intent)
                finish()
            } else {
                cursor.close()
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }
    }



}
