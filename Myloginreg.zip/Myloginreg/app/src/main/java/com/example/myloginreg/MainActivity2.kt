package com.example.myloginreg

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
       val fname = findViewById<EditText>(R.id.editTextText3)
        val username = findViewById<EditText>(R.id.editTextText4)
        val password = findViewById<EditText>(R.id.editTextText5)
        val save = findViewById<Button>(R.id.button3)

        var db = openOrCreateDatabase("UserDB", MODE_PRIVATE, null)
        db.execSQL("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, fname TEXT, username TEXT, password TEXT)")

        save.setOnClickListener {
            val fNameText = fname.text.toString()
            val usernameText = username.text.toString()
            val passwordText = password.text.toString()

            if (fNameText.isNotEmpty() && usernameText.isNotEmpty() && passwordText.isNotEmpty()) {
                val values = ContentValues()
                values.put("fname", fNameText)
                values.put("username", usernameText)
                values.put("password", passwordText)

                val result = db.insert("users", null, values)
                if (result != -1L) {
                    Toast.makeText(this, "Registered!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "Failed!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Fill all fields!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
