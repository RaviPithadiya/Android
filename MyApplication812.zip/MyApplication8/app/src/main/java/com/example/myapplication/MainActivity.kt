package com.example.myapplication

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.database.sqlite.SQLiteDatabase
import android.content.ContentValues

class MainActivity : AppCompatActivity() {

    private lateinit var db: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Open or create database named "user_data.db"
        db = openOrCreateDatabase("mca.db", MODE_PRIVATE, null)

        // Create table if it doesn't exist
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                firstname TEXT,
                lastname TEXT,
                gender TEXT,
                hobbies TEXT,
                country TEXT
            )
        """)

        val firstname = findViewById<EditText>(R.id.edittextName)
        val lastname = findViewById<EditText>(R.id.edittextName1)
        val group = findViewById<RadioGroup>(R.id.radioGroupGender)
        val checkbox = findViewById<CheckBox>(R.id.checkReading)
        val checkbox1 = findViewById<CheckBox>(R.id.checkMusic)
        val checkbox2 = findViewById<CheckBox>(R.id.checkSports)
        val spinner = findViewById<Spinner>(R.id.spinnerCountry)
        val button = findViewById<Button>(R.id.button)
        val textView = findViewById<TextView>(R.id.textView)
        val listView = findViewById<ListView>(R.id.listView)

        val items = arrayOf("Rajkot", "Surat", "Jamnagar")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)

        val cities = arrayOf("Rajkot", "Baroda", "Bhavnagar", "Junagadh", "Morbi")
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, cities)
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedItem = cities[position]
            Toast.makeText(this, "Clicked: $selectedItem", Toast.LENGTH_SHORT).show()
        }

        button.setOnClickListener {
            val firstNameStr = firstname.text.toString().trim()
            val lastNameStr = lastname.text.toString().trim()

            // Basic validation
            if (firstNameStr.isEmpty() || lastNameStr.isEmpty()) {
                Toast.makeText(this, "Please enter both first and last name.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val name = "$firstNameStr $lastNameStr"
            val genderId = group.checkedRadioButtonId
            val gender = if (genderId != -1) findViewById<RadioButton>(genderId).text.toString() else "Not Selected"

            val hobbiesList = mutableListOf<String>()
            if (checkbox.isChecked) hobbiesList.add("Reading")
            if (checkbox1.isChecked) hobbiesList.add("Music")
            if (checkbox2.isChecked) hobbiesList.add("Sports")
            val hobbies = hobbiesList.joinToString(", ")

            val country = spinner.selectedItem.toString()

            // Insert data into SQLite database
            val values = ContentValues().apply {
                put("firstname", firstNameStr)
                put("lastname", lastNameStr)
                put("gender", gender)
                put("hobbies", hobbies)
                put("country", country)
            }

            val rowId = db.insert("users", null, values)
            if (rowId != -1L) {
                Toast.makeText(this, "Data saved successfully!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Failed to save data", Toast.LENGTH_SHORT).show()
            }

            // Show data in TextView
            textView.text = "Name: $name\nGender: $gender\nHobbies: $hobbies\nCountry: $country"
        }
    }

    override fun onDestroy() {
        if (::db.isInitialized && db.isOpen) {
            db.close() // Close DB when activity is destroyed
        }
        super.onDestroy()
    }
}
